<?php
use Sterc\SeoSuite\Snippets\Meta;

$meta = new Meta($modx);

return $meta->process($scriptProperties);