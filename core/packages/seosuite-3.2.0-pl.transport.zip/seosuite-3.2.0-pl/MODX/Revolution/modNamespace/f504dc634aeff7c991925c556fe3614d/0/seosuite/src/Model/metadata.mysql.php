<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Sterc\\SeoSuite\\Model',
    'namespacePrefix' => 'Sterc\\SeoSuite',
    'class_map' => 
    array (
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Sterc\\SeoSuite\\Model\\SeoSuiteSocial',
            1 => 'Sterc\\SeoSuite\\Model\\SeoSuiteUrl',
            2 => 'Sterc\\SeoSuite\\Model\\SeoSuiteResource',
            3 => 'Sterc\\SeoSuite\\Model\\SeoSuiteRedirect',
        ),
    ),
);